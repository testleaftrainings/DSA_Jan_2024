package week1.day1;

public class FindBiggestNumber {
public static void main(String[] args) {
	int a=10;
	int b=50;
	int c=300;
	
	if(a>b && a>c) {
		System.out.println(a+"is the biggest number");
	}else if (b>a && b>c) {
		System.out.println(b+"is the biggest number");
	}else {
		System.out.println("The biggest number is c");
	}
}
}

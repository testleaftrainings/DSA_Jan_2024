package week1.day1;

public class ArmStrongNumber{
public static void main(String[] args){


//Initialize an input
int num=153;
//Initialize temp variable as sum
int sum =0;

int ans=num;

       while(num>0){
      //find remainder by using % operator
      int remainder=num%10;
      //Cube- remainder values
       sum=sum+(remainder*remainder*remainder);
       num=num/10;
}
    if(ans==sum){
System.out.println("This given input is ArmStrongNumber");   
 }else{
System.out.println("This given input is ArmStrongNumber");   
}

}
}
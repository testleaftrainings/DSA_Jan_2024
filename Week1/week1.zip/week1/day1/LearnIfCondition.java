package week1.day1;

public class LearnIfCondition {
public static void main(String[] args) {
	int a=2;

	if(a<0){
	System.out.println("Condition true");
	}else {
		System.out.println("Condition is false");
	}
	

}
}

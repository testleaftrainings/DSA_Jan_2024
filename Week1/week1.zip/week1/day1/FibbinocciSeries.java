package week1.day1;

	public class FibbinocciSeries{

		public static void main(String []args){

		//Initialize 3 int variables (Tip: firstNum = 0, secNum = 1, sum = 0)
		int firstNumber=0;
		System.out.println(firstNumber);
		int secondNumber=1;
		System.out.println(secondNumber);
		int sum=0;
		//Iterate from 1 to the 11
		for(int i=1;i<11;i++){
		      sum =firstNumber+secondNumber;                        //  f   second    s
		       System.out.println(sum);                                          //  0    1         1
		      firstNumber=secondNumber;                            //   f   second    s
		      secondNumber=sum;  
}
}
}
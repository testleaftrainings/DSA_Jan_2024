package week1.day1;

public class LearnForLoop {

	public static void main(String[] args) {
		//Increment for loop
		//type for and press ctrl+ space bar 
		for (int i = 0; i < 10; i++) {
		//	System.out.println(i);
		}
		
		for (int i = 10; i >0; i--) {
			System.out.println(i);
			
		}
		//System.out.println("condition is wrong");
		
	}
	
}

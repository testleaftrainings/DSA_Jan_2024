package week1.day1;

public class PrintOddNumbers{

	public static void main (String[] args){

		//Iterate the for loop from 1 to 20
		for (int i=1; i<=20;i++){
			//check condition, If it is match the odd numbers will be printed
			if(i%2!=0){
				System.out.println(i);
			}
		}
	}
}
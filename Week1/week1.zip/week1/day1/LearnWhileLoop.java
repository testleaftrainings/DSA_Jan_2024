package week1.day1;

public class LearnWhileLoop {

	public static void main(String[] args) {
		
		int a=1;
		while (a<10) {
		//	System.out.println(a);
			a++;
		}
		
		int b=10;
		while (b>0) {
			System.out.println(b);
			b--;
		}
		
		
		
	}
}

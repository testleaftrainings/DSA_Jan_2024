package week1.day1;

public class FirstProgram {

	//type main and press ctrl+space bar --> press enter
	public static void main(String[] args) {
		
		//syso and press ctrl+space bar --> press enter
		System.out.println("This is my first program");
	}
}

package week1.day1;

public class Factorial{

public static void main(String []args){

//Initilize the temp variable as fact
int fact=1;
//Itearte the values from 5 to 1
  for (int i=5;i>0;i--){
         fact=fact * i;
         System.out.println(fact);
}
}
}
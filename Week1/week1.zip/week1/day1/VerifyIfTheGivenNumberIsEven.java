package week1.day1;

public class VerifyIfTheGivenNumberIsEven {

	public static void main(String[] args) {
		int a=11;
		if(a%2==0) {
			System.out.println("The given Number is Even");
		}else {
			System.out.println("The given Number is Odd");
		}
	}
}
